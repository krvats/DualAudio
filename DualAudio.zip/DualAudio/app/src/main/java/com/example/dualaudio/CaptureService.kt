package com.example.dualaudio

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.os.Process

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var worker: Thread? = null
    @Volatile private var running = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("cap", "Dual audio", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "cap")
            .setContentTitle("Dual audio running")
            .setSmallIcon(android.R.drawable.ic_media_play).build()
        startForeground(1, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra("data", Intent::class.java) else @Suppress("DEPRECATION") intent?.getParcelableExtra("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)

        val config = AudioPlaybackCaptureConfiguration.Builder(projection!!)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .excludeUid(Process.myUid())
            .build()

        val fmt = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(44100)
            .setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build()
        val rec = AudioRecord.Builder().setAudioPlaybackCaptureConfig(config).setAudioFormat(fmt).build()

        val outFmt = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(44100)
            .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build()
        val minBuf = AudioTrack.getMinBufferSize(44100, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
        val track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).build())
            .setAudioFormat(outFmt)
            .setBufferSizeInBytes(minBuf * 4)
            .setTransferMode(AudioTrack.MODE_STREAM).build()

        val am = getSystemService(AudioManager::class.java)
        val outs = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        val btTypes = setOf(
            AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
            AudioDeviceInfo.TYPE_BLE_HEADSET,
            AudioDeviceInfo.TYPE_BLE_SPEAKER,
            AudioDeviceInfo.TYPE_BLE_BROADCAST
        )
        val bt = outs.firstOrNull { it.type in btTypes }
        val ok = bt != null && track.setPreferredDevice(bt)
        if (!ok) {
            // Don't play to aux a second time: stop and show what Android sees.
            val seen = outs.joinToString { "${it.type}:${it.productName}" }
            android.widget.Toast.makeText(
                this, "Bluetooth output not usable. Seen: $seen", android.widget.Toast.LENGTH_LONG
            ).show()
            rec.release(); track.release()
            stopSelf()
            return START_NOT_STICKY
        }

        running = true
        worker = Thread {
            val buf = ByteArray(minBuf)
            rec.startRecording(); track.play()
            Thread.sleep(700)
            val routed = track.routedDevice
            if (routed == null || routed.type !in btTypes) {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    android.widget.Toast.makeText(
                        this, "Android still routes to type ${routed?.type} (aux). Stopped.",
                        android.widget.Toast.LENGTH_LONG
                    ).show()
                    stopSelf()
                }
                running = false
            }
            while (running) {
                val n = rec.read(buf, 0, buf.size)
                if (n > 0) track.write(buf, 0, n)
            }
            rec.stop(); rec.release(); track.stop(); track.release()
        }.also { it.start() }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        projection?.stop()
        super.onDestroy()
    }
}
